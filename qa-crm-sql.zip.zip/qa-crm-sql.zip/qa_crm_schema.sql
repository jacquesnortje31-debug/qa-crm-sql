-- ======================================
-- AGENTS
-- ======================================
CREATE TABLE agents (
    agent_id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    team VARCHAR(50),
    supervisor VARCHAR(100)
);

INSERT INTO agents (name, team, supervisor) VALUES
  ('John Doe', 'Team A', 'Mary Smith'),
  ('Sarah Lee', 'Team B', 'Tom Jones'),
  ('David Brown', 'Team A', 'Mary Smith'),
  ('Emily Carter', 'Team C', 'Tom Jones');

-- ======================================
-- AGENT PERFORMANCE
-- ======================================
CREATE TABLE agent_performance (
    performance_id SERIAL PRIMARY KEY,
    agent_id INT NOT NULL REFERENCES agents(agent_id),
    review_date DATE NOT NULL,
    calls_made INT DEFAULT 0,
    client_connects INT DEFAULT 0,
    sales_achieved INT DEFAULT 0,
    pause_time_minutes INT DEFAULT 0,
    qa_score DECIMAL(5,2),
    notes TEXT
);

INSERT INTO agent_performance (agent_id, review_date, calls_made, client_connects, sales_achieved, pause_time_minutes, qa_score, notes) VALUES
  (1, '2025-09-23', 62, 58, 6, 540, 88.0, 'Strong start of week'),
  (1, '2025-09-24', 60, 55, 5, 590, 82.0, 'Met targets, slightly high pause'),
  (2, '2025-09-23', 64, 59, 7, 500, 91.0, 'Excellent performance'),
  (2, '2025-09-24', 61, 57, 6, 480, 89.0, 'Consistent delivery'),
  (3, '2025-09-23', 50, 45, 3, 610, 70.0, 'Below targets, high pause time'),
  (3, '2025-09-24', 55, 50, 4, 620, 68.0, 'Needs improvement'),
  (4, '2025-09-23', 63, 60, 5, 530, 85.0, 'Good sales, balanced day'),
  (4, '2025-09-24', 60, 55, 5, 520, 84.5, 'Consistent performance');

-- ======================================
-- QA REVIEWS
-- ======================================
CREATE TABLE qa_reviews (
    review_id SERIAL PRIMARY KEY,
    agent_id INT NOT NULL REFERENCES agents(agent_id),
    review_date DATE NOT NULL,
    scorecard_id INT NOT NULL,
    item_scores_json JSONB,
    overall_score DECIMAL(5,2),
    notes TEXT
);

INSERT INTO qa_reviews (agent_id, review_date, scorecard_id, item_scores_json, overall_score, notes) VALUES
  (1, '2025-09-23', 101,
   '[{"item":"greeting","score":1},{"item":"compliance","score":0.9},{"item":"closing","score":0.8}]',
   86.0, 'Solid compliance, closing needs polish'),
  (2, '2025-09-23', 101,
   '[{"item":"greeting","score":1},{"item":"compliance","score":1},{"item":"closing","score":0.95}]',
   95.0, 'Outstanding call structure'),
  (3, '2025-09-23', 101,
   '[{"item":"greeting","score":0.7},{"item":"compliance","score":0.8},{"item":"closing","score":0.6}]',
   70.0, 'Weak greeting and closing'),
  (4, '2025-09-23', 101,
   '[{"item":"greeting","score":0.95},{"item":"compliance","score":0.9},{"item":"closing","score":0.85}]',
   90.0, 'Well balanced call');

-- ======================================
-- DISCUSSIONS & WARNINGS
-- ======================================
CREATE TABLE discussions (
    discussion_id SERIAL PRIMARY KEY,
    agent_id INT NOT NULL REFERENCES agents(agent_id),
    discussion_date DATE NOT NULL,
    supervisor VARCHAR(100) NOT NULL,
    notes TEXT,
    warnings_json JSONB,
    resolution_status VARCHAR(20) CHECK (resolution_status IN ('open','resolved'))
);

INSERT INTO discussions (agent_id, discussion_date, supervisor, notes, warnings_json, resolution_status) VALUES
  (3, '2025-09-24', 'Mary Smith', 'Late login observed twice this week', '[{"type":"attendance","note":"2 late logins"}]', 'open'),
  (1, '2025-09-24', 'Mary Smith', 'Minor script deviation spotted', '[{"type":"compliance","note":"Missed greeting line once"}]', 'resolved');

-- ======================================
-- WEEKLY FEEDBACK
-- ======================================
CREATE TABLE weekly_feedback (
    feedback_id SERIAL PRIMARY KEY,
    agent_id INT NOT NULL REFERENCES agents(agent_id),
    week_start_date DATE NOT NULL,
    product_issues TEXT,
    sales_obstacles TEXT,
    supervisor_notes TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);

INSERT INTO weekly_feedback (agent_id, week_start_date, product_issues, sales_obstacles, supervisor_notes) VALUES
  (1, '2025-09-23', 'Script for Product A is lengthy', 'Clients hesitant on upsell pitch', 'Coach on shorter phrasing'),
  (2, '2025-09-23', 'No major product issues', 'Clients responded well', 'Keep consistent style'),
  (3, '2025-09-23', 'Product B objections too frequent', 'Customer pushback on pricing', 'Roleplay objection handling'),
  (4, '2025-09-23', 'Clients confuse Product C with competitor', 'Harder close rate', 'Provide competitor comparison sheet');
