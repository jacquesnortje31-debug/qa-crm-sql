# QA CRM SQL + Lovable Integration

This repository contains a PostgreSQL schema and seed data for a QA CRM system, along with a Lovable prompt for frontend/dashboard setup.

## Setup Instructions

1. Unzip the folder.
2. Open your PostgreSQL client (Supabase SQL Editor, pgAdmin, psql).  
3. Run the SQL file:
   ```sql
   \i qa_crm_schema.sql
